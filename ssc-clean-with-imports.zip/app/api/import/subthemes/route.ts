import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabaseServer'


function parseCSV(text) {
  const rows = [];
  let i = 0, cur = '', inQuotes = false, row = [];
  while (i < text.length) {
    const ch = text[i++];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i] === '"') { cur += '"'; i++; }
        else { inQuotes = false; }
      } else cur += ch;
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === ',') { row.push(cur); cur = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i] === '\n') i++;
        row.push(cur); rows.push(row); row = []; cur = '';
      } else cur += ch;
    }
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }
  // convert to objects by header
  if (!rows.length) return [];
  const header = rows[0].map(h => h.trim());
  return rows.slice(1).filter(r => r.length && r.some(c => c && c.trim().length)).map(r => {
    const obj = {};
    for (let j=0;j<header.length;j++) obj[header[j]] = (r[j] ?? '').trim();
    return obj;
  });
}


export async function POST(req: Request) {
  const url = new URL(req.url)
  const mode = url.searchParams.get('mode') || 'upsert'
  const form = await req.formData()
  const file = form.get('file') as File | null
  if (!file) return NextResponse.json({ error: 'Missing file' }, { status: 400 })
  const text = await file.text()
  const rows = parseCSV(text)

  const supabase = createClient()
  if (mode === 'replace') await supabase.from('subthemes').delete().neq('id', '')

  for (const r of rows) {
    // resolve theme_id
    let theme_id = r.theme_id || null
    if (!theme_id && r.theme_code) {
      const { data: t } = await supabase.from('themes').select('id').eq('code', r.theme_code).maybeSingle()
      theme_id = t?.id || null
    }
    if (!theme_id) continue

    const record: any = {
      theme_id,
      code: r.code || null,
      name: r.name,
      description: r.description || null,
      sort_order: r.sort_order ? Number(r.sort_order) : null,
    }
    if (!record.name) continue

    if (r.id) {
      await supabase.from('subthemes').upsert({ id: r.id, ...record })
    } else if (r.code) {
      const { data: existing } = await supabase.from('subthemes').select('id').eq('code', r.code).maybeSingle()
      if (existing?.id) await supabase.from('subthemes').update(record).eq('id', existing.id)
      else await supabase.from('subthemes').insert(record)
    } else {
      await supabase.from('subthemes').insert(record)
    }
  }

  return NextResponse.json({ ok: true })
}
