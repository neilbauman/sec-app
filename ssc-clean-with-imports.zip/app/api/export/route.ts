import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabaseServer'

function csvEscape(v: any): string {
  if (v === null || v === undefined) return ''
  const s = String(v)
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"'
  return s
}

export async function GET() {
  const supabase = createClient()

  const [{ data: pillars }, { data: themes }, { data: subs }, { data: standards }, { data: indicators }] = await Promise.all([
    supabase.from('pillars').select('*'),
    supabase.from('themes').select('*'),
    supabase.from('subthemes').select('*'),
    supabase.from('standards').select('*'),
    supabase.from('indicators').select('*'),
  ])

  const rows: string[] = []
  rows.push(['level','pillar_name','theme_name','subtheme_name','standard_desc','indicator_name','indicator_description'].join(','))

  const themesByPillar = new Map<string, any[]>()
  themes?.forEach(t => themesByPillar.set(t.pillar_id, [...(themesByPillar.get(t.pillar_id) || []), t]))
  const subsByTheme = new Map<string, any[]>()
  subs?.forEach(s => subsByTheme.set(s.theme_id, [...(subsByTheme.get(s.theme_id) || []), s]))

  const indsBy = {
    pillar: new Map<string, any[]>(),
    theme: new Map<string, any[]>(),
    sub: new Map<string, any[]>(),
    std: new Map<string, any[]>(),
  }
  indicators?.forEach(i => {
    if (i.pillar_id) indsBy.pillar.set(i.pillar_id, [...(indsBy.pillar.get(i.pillar_id) || []), i])
    if (i.theme_id) indsBy.theme.set(i.theme_id, [...(indsBy.theme.get(i.theme_id) || []), i])
    if (i.subtheme_id) indsBy.sub.set(i.subtheme_id, [...(indsBy.sub.get(i.subtheme_id) || []), i])
    if (i.standard_id) indsBy.std.set(i.standard_id, [...(indsBy.std.get(i.standard_id) || []), i])
  })
  const pick = (xs?: any[]) => (xs && xs.length ? (xs.find(x => x.is_default) || xs[0]) : undefined)

  for (const p of (pillars || [])) {
    const pInd = pick(indsBy.pillar.get(p.id))
    rows.push(['pillar', csvEscape(p.name), '', '', '', csvEscape(pInd?.name || ''), csvEscape(pInd?.description || '')].join(','))
    const tList = themesByPillar.get(p.id) || []
    for (const t of tList) {
      const tInd = pick(indsBy.theme.get(t.id)) || pInd
      rows.push(['theme', csvEscape(p.name), csvEscape(t.name), '', '', csvEscape(tInd?.name || ''), csvEscape(tInd?.description || '')].join(','))
      const sList = subsByTheme.get(t.id) || []
      for (const s of sList) {
        rows.push(['subtheme', csvEscape(p.name), csvEscape(t.name), csvEscape(s.name), '', '', ''].join(','))
        const dList = (standards || []).filter(d => d.subtheme_id === s.id)
        for (const d of dList) {
          const dInd = pick(indsBy.std.get(d.id)) || tInd || pInd
          rows.push(['standard', csvEscape(p.name), csvEscape(t.name), csvEscape(s.name), csvEscape(d.description || ''), csvEscape(dInd?.name || ''), csvEscape(dInd?.description || '')].join(','))
        }
      }
    }
  }

  const csv = rows.join('\n')
  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="framework_export.csv"',
    },
  })
}
