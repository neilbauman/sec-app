import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabaseServer'

export async function GET() {
  const supabase = createClient()

  const [{ data: pillars, error: e1 }, { data: themes, error: e2 }, { data: subs, error: e3 },
         { data: standards, error: e4 }, { data: indicators, error: e5 }] = await Promise.all([
    supabase.from('pillars').select('*').order('sort_order', { ascending: true }),
    supabase.from('themes').select('*').order('sort_order', { ascending: true }),
    supabase.from('subthemes').select('*').order('sort_order', { ascending: true }),
    supabase.from('standards').select('*').order('sort_order', { ascending: true }),
    supabase.from('indicators').select('*'),
  ])

  const err = e1?.message || e2?.message || e3?.message || e4?.message || e5?.message
  if (err) return NextResponse.json({ error: err }, { status: 400 })

  const indBy = {
    pillar: new Map<string, any[]>(),
    theme: new Map<string, any[]>(),
    sub: new Map<string, any[]>(),
    std: new Map<string, any[]>(),
  }
  indicators?.forEach(i => {
    if (i.pillar_id) indBy.pillar.set(i.pillar_id, [...(indBy.pillar.get(i.pillar_id) || []), i])
    if (i.theme_id) indBy.theme.set(i.theme_id, [...(indBy.theme.get(i.theme_id) || []), i])
    if (i.subtheme_id) indBy.sub.set(i.subtheme_id, [...(indBy.sub.get(i.subtheme_id) || []), i])
    if (i.standard_id) indBy.std.set(i.standard_id, [...(indBy.std.get(i.standard_id) || []), i])
  })
  const pick = (xs?: any[]) => (xs && xs.length ? (xs.find(x => x.is_default) || xs[0]) : undefined)

  const themesByPillar = new Map<string, any[]>()
  themes?.forEach(t => themesByPillar.set(t.pillar_id, [...(themesByPillar.get(t.pillar_id) || []), t]))
  const subsByTheme = new Map<string, any[]>()
  subs?.forEach(s => subsByTheme.set(s.theme_id, [...(subsByTheme.get(s.theme_id) || []), s]))
  const stdsBySub = new Map<string, any[]>()
  standards?.forEach(d => stdsBySub.set(d.subtheme_id, [...(stdsBySub.get(d.subtheme_id) || []), d]))

  const tree = (pillars || []).map((p: any) => {
    const pind = pick(indBy.pillar.get(p.id))
    const tChildren = (themesByPillar.get(p.id) || []).map((t: any) => {
      const tind = pick(indBy.theme.get(t.id)) || pind
      const sChildren = (subsByTheme.get(t.id) || []).map((s: any) => {
        const sind = pick(indBy.sub.get(s.id)) || tind || pind
        const dChildrenRaw = (stdsBySub.get(s.id) || [])
        const dChildren = dChildrenRaw.length === 0
          ? []
          : dChildrenRaw.map((d: any) => {
              const dind = pick(indBy.std.get(d.id)) || sind
              return {
                key: `std-${d.id}`,
                level: 'standard',
                pillar: p, theme: t, subtheme: s, standard: d,
                indicator: dind ? { id: dind.id, name: dind.name, description: dind.description } : null,
                children: [],
              }
            })
        return {
          key: `sub-${s.id}`,
          level: 'subtheme',
          pillar: p, theme: t, subtheme: s, standard: null,
          indicator: sind ? { id: sind.id, name: sind.name, description: sind.description } : null,
          children: dChildren,
        }
      })
      return {
        key: `theme-${t.id}`,
        level: 'theme',
        pillar: p, theme: t, subtheme: null, standard: null,
        indicator: tind ? { id: tind.id, name: tind.name, description: tind.description } : null,
        children: sChildren,
      }
    })
    return {
      key: `pillar-${p.id}`,
      level: 'pillar',
      pillar: p, theme: null, subtheme: null, standard: null,
      indicator: pind ? { id: pind.id, name: pind.name, description: pind.description } : null,
      children: tChildren,
    }
  })

  return NextResponse.json({ tree })
}
